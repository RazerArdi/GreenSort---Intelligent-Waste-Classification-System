import os

folder = "Vegetation"
files = sorted(os.listdir(folder))
start_number = 437

for index, filename in enumerate(files):
    ext = os.path.splitext(filename)[1]
    new_name = f"Vegetation_{start_number + index}{ext}"
    os.rename(os.path.join(folder, filename), os.path.join(folder, new_name))
